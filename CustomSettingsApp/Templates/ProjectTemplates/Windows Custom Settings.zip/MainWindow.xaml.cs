﻿using System.IO;
using System.Windows;

namespace System_Backup_Restore
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string settingsFilesPath = @".\links";

        private void RunBatFile(string filepath)
        {
            if (File.Exists(filepath))
            {
                // for debugging
                //OutputTextBox.Text += $"{filepath}{Environment.NewLine}";
                //OutputTextBox.Text += $"exists{Environment.NewLine}";

                // "/K" to run cmd and remain open; "/C" to run cmd and close
                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/K " + filepath);
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                proc.WaitForExit();
                proc.Close();
            }
            else
            {
                OutputTextBox.Text += $"{filepath} doesnt exist.{Environment.NewLine}";
            }
        }
        private void RunBatFileClosed(string filepath)
        {
            if (File.Exists(filepath))
            {
                // "/K" to run cmd and remain open; "/C" to run cmd and close
                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/C " + filepath);
                procStartInfo.CreateNoWindow = true;
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                proc.Close();
            }
            else
            {
                OutputTextBox.Text += $"{filepath} doesnt exist.{Environment.NewLine}";
            }
        }

        private void RunBatFileElevated(string filepath)
        {
            if (File.Exists(filepath))
            {
                // "/K" to run cmd and remain open; "/C" to run cmd and close
                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/K " + filepath);
                procStartInfo.UseShellExecute = true;
                procStartInfo.Verb = "runas";
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                proc.Start();
                proc.WaitForExit();
                proc.Close();
            }
            else
            {
                OutputTextBox.Text += $"{filepath} doesnt exist.{Environment.NewLine}";
            }
        }

        private void Backup_Files_Folders(object sender, RoutedEventArgs e)
        {
            RunBatFile(@$"{settingsFilesPath}\backuppc.lnk");
        }

        private void Restore_Files_Folders(object sender, RoutedEventArgs e)
        {
            RunBatFile(@$"{settingsFilesPath}\restorepc.lnk");
        }

        private void File_Hash(object sender, RoutedEventArgs e)
        {
            RunBatFileClosed(@$"{settingsFilesPath}\FileHash.lnk");
        }
        private void Task_Widget(object sender, RoutedEventArgs e)
        {
            RunBatFileClosed(@$"{settingsFilesPath}\taskWidget.lnk");
        }

        private void List_Installed_Programs(object sender, RoutedEventArgs e)
        {
            RunBatFileClosed(@$"{settingsFilesPath}\list_installed_programs.lnk");
        }
        
        private void Context_Menu(object sender, RoutedEventArgs e)
        {
            RunBatFile(@$"{settingsFilesPath}\context_menu.lnk");
        }
        
        private void Remove_OneDrive_Path(object sender, RoutedEventArgs e)
        {
            RunBatFile(@$"{settingsFilesPath}\onedrive_path.lnk");
        }

        private void Stop_Connected_User_Ex(object sender, RoutedEventArgs e)
        {
            RunBatFileElevated(@$"{settingsFilesPath}\connectedUserExperience.lnk");
        }

        private void Stop_HpTouchpoint_Analytics(object sender, RoutedEventArgs e)
        {
            RunBatFileElevated(@$"{settingsFilesPath}\HpTouchpointAnalytics.lnk");
        }

        private void Stop_XTU(object sender, RoutedEventArgs e)
        {
            RunBatFileElevated(@$"{settingsFilesPath}\xtu3.lnk");
        }

        private void High_Performace_Power(object sender, RoutedEventArgs e)
        {
            RunBatFileElevated(@$"{settingsFilesPath}\highPerformancePowerPlan.lnk");
        }

        private void Firewall_logging(object sender, RoutedEventArgs e)
        {
            RunBatFileElevated(@$"{settingsFilesPath}\toggle_logging.lnk");
        }
    }
}